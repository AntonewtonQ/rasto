"""Paleta Rasto: fonte única dos valores e cálculo dos contrastes WCAG 2.2."""
import json, sys

PAL = {
  "light": {
    "bg":              "#FAF9F6",
    "surface":         "#FFFFFF",
    "surface-sunken":  "#F2F0EB",
    "border":          "#E3DFD7",
    "border-strong":   "#8A8494",
    "text":            "#1B1A22",
    "text-muted":      "#55515F",
    "text-subtle":     "#6E6979",
    "primary":         "#3A2D8F",
    "primary-hover":   "#2E2373",
    "primary-subtle":  "#EEEBFA",
    "on-primary":      "#FFFFFF",
    "secondary":       "#A8461E",
    "secondary-subtle":"#FBEDE5",
    "on-secondary":    "#FFFFFF",
    "success":         "#1C6B45",
    "success-subtle":  "#E5F4EC",
    "warning":         "#7A5000",
    "warning-subtle":  "#FDF3D8",
    "error":           "#B0221B",
    "error-subtle":    "#FCE9E7",
    "info":            "#0D5F78",
    "info-subtle":     "#E3F2F7",
    "focus":           "#3A2D8F",
  },
  "dark": {
    "bg":              "#111017",
    "surface":         "#1A1921",
    "surface-sunken":  "#0C0B10",
    "border":          "#2F2D39",
    "border-strong":   "#77728A",
    "text":            "#EEEDF3",
    "text-muted":      "#AEAABB",
    "text-subtle":     "#9692A4",
    "primary":         "#B4AAFF",
    "primary-hover":   "#C9C2FF",
    "primary-subtle":  "#272246",
    "on-primary":      "#17123A",
    "secondary":       "#F09A70",
    "secondary-subtle":"#3A2219",
    "on-secondary":    "#2A1208",
    "success":         "#72D3A2",
    "success-subtle":  "#11291D",
    "warning":         "#F0C55A",
    "warning-subtle":  "#2E2408",
    "error":           "#FF9088",
    "error-subtle":    "#361614",
    "info":            "#72C8E3",
    "info-subtle":     "#0F2830",
    "focus":           "#B4AAFF",
  },
}

def lum(h):
    h = h.lstrip('#'); rgb = [int(h[i:i+2], 16)/255 for i in (0, 2, 4)]
    lin = [c/12.92 if c <= 0.04045 else ((c+0.055)/1.055)**2.4 for c in rgb]
    return 0.2126*lin[0] + 0.7152*lin[1] + 0.0722*lin[2]

def ratio(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la+0.05)/(lb+0.05)

# (primeiro plano, fundo, mínimo, uso)
CHECKS = [
  ("text", "bg", 4.5, "Texto principal sobre fundo"),
  ("text", "surface", 4.5, "Texto principal sobre superfície"),
  ("text-muted", "surface", 4.5, "Texto secundário"),
  ("text-muted", "surface-sunken", 4.5, "Texto secundário em área rebaixada"),
  ("text-subtle", "surface", 4.5, "Placeholder e legendas"),
  ("border-strong", "surface", 3.0, "Contorno de campos e controlos (não-texto)"),
  ("primary", "surface", 4.5, "Ligações e texto primário"),
  ("primary", "bg", 4.5, "Ligações sobre fundo"),
  ("on-primary", "primary", 4.5, "Texto em botão primário"),
  ("on-primary", "primary-hover", 4.5, "Botão primário em hover"),
  ("primary", "primary-subtle", 4.5, "Selo validado: texto sobre fundo do selo"),
  ("secondary", "surface", 4.5, "Destaque laterite como texto"),
  ("on-secondary", "secondary", 4.5, "Texto sobre laterite"),
  ("secondary", "secondary-subtle", 4.5, "Laterite sobre fundo laterite"),
  ("success", "surface", 4.5, "Sucesso: texto e ícone"),
  ("success", "success-subtle", 4.5, "Sucesso em banner"),
  ("warning", "surface", 4.5, "Aviso: texto e ícone"),
  ("warning", "warning-subtle", 4.5, "Aviso em banner"),
  ("error", "surface", 4.5, "Erro: texto e ícone"),
  ("error", "error-subtle", 4.5, "Erro em banner"),
  ("info", "surface", 4.5, "Informação: texto e ícone"),
  ("info", "info-subtle", 4.5, "Informação em banner"),
  ("focus", "surface", 3.0, "Anel de foco (não-texto)"),
]

def report():
    rows, ok = [], True
    for mode in ("light", "dark"):
        p = PAL[mode]
        for fg, bg, mn, use in CHECKS:
            r = ratio(p[fg], p[bg])
            passed = r >= mn
            ok &= passed
            rows.append((mode, fg, bg, p[fg], p[bg], round(r, 2), mn, passed, use))
    return rows, ok

if __name__ == "__main__":
    rows, ok = report()
    for r in rows:
        print(f"{r[0]:5} {r[1]:15} on {r[2]:16} {r[5]:6} min {r[6]} {'OK' if r[7] else 'FALHA'}")
    print("TODOS OK" if ok else "HÁ FALHAS")
    # extra: distância laterite vs erro (claro) para o relatório
    print("laterite vs erro (claro):", round(ratio(PAL['light']['secondary'], PAL['light']['error']), 2))
    json.dump(rows, open("contrast.json", "w"), ensure_ascii=False, indent=1)
