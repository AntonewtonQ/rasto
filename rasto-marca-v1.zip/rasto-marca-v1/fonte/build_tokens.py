"""Gera tokens W3C (DTCG) e variáveis CSS a partir de palette.py."""
import json, os
from palette import PAL, CHECKS, ratio

os.makedirs("out/tokens", exist_ok=True)
px = lambda v: {"value": v, "unit": "px"}

DESC = {
 "bg": "Fundo da aplicação (papel).", "surface": "Cartões, folhas, campos.",
 "surface-sunken": "Áreas rebaixadas, listas agrupadas.", "border": "Divisórias decorativas (sem função).",
 "border-strong": "Contorno de campos e controlos; ≥ 3:1 com a superfície.",
 "text": "Texto principal.", "text-muted": "Texto secundário.", "text-subtle": "Placeholders, legendas, datas.",
 "primary": "Tinta: acção principal, ligações e todos os selos de validação.",
 "primary-hover": "Tinta em hover e pressionado.", "primary-subtle": "Fundo de selos e realces da tinta.",
 "on-primary": "Texto sobre tinta.", "secondary": "Laterite: energia e progresso (marcos, % da ronda). Nunca para estados de erro ou aviso.",
 "secondary-subtle": "Fundo laterite.", "on-secondary": "Texto sobre laterite.",
 "success": "Operação concluída. Não é sinónimo de 'validado'.", "success-subtle": "Fundo de sucesso.",
 "warning": "Aviso, prazos a expirar, validado com aviso.", "warning-subtle": "Fundo de aviso.",
 "error": "Erro e recusa técnica. Sempre com ícone e texto.", "error-subtle": "Fundo de erro.",
 "info": "Informação neutra.", "info-subtle": "Fundo de informação.", "focus": "Anel de foco (2 px, afastado 2 px).",
}

def contrasts(mode, name):
    out = {}
    for fg, bg, mn, use in CHECKS:
        if fg == name:
            out[f"sobre {bg}"] = {"rácio": round(ratio(PAL[mode][fg], PAL[mode][bg]), 2), "mínimo": mn}
    return out

color = {"$type": "color"}
for mode in ("light", "dark"):
    color[mode] = {}
    for k, v in PAL[mode].items():
        t = {"$value": v, "$description": DESC.get(k, "")}
        c = contrasts(mode, k)
        if c: t["$extensions"] = {"ao.rasto.wcag": c}
        color[mode][k] = t

FONTS = {
 "sans": ["Inter", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
 "serif": ["Lora", "Georgia", "Times New Roman", "serif"],
}
SCALE = [  # nome, família, tamanho, linha, peso, tracking(em)
 ("display", "serif", 40, 46, 600, -0.01),
 ("h1", "sans", 28, 34, 600, -0.015),
 ("h2", "sans", 22, 28, 600, -0.01),
 ("h3", "sans", 18, 24, 600, 0),
 ("body-lg", "sans", 18, 28, 400, 0),
 ("body", "sans", 16, 24, 400, 0),
 ("body-sm", "sans", 14, 20, 400, 0),
 ("label", "sans", 14, 20, 500, 0),
 ("caption", "sans", 12, 16, 500, 0.01),
 ("metric-lg", "sans", 34, 40, 600, -0.02),
 ("metric", "sans", 20, 26, 600, -0.01),
]
typo = {"$type": "typography"}
for n, fam, size, lh, w, tr in SCALE:
    typo[n] = {"$value": {"fontFamily": f"{{font.family.{fam}}}", "fontSize": px(size),
               "lineHeight": round(lh/size, 3), "fontWeight": w,
               "letterSpacing": {"value": tr, "unit": "em"}}}
    if n.startswith("metric"):
        typo[n]["$description"] = "Sempre com font-variant-numeric: tabular-nums."

tokens = {
 "$description": "Rasto (nome provisório) · tokens de marca v1.0 · 3 Nov 2026 · formato W3C Design Tokens",
 "color": color,
 "font": {
   "family": {"$type": "fontFamily", "sans": {"$value": FONTS["sans"]}, "serif": {"$value": FONTS["serif"], "$description": "Só títulos editoriais: capa, página de entrada, relatório. Nunca em números."}},
   "weight": {"$type": "fontWeight", "regular": {"$value": 400}, "medium": {"$value": 500}, "semibold": {"$value": 600}},
 },
 "typography": typo,
 "space": {"$type": "dimension", **{str(k): {"$value": px(k*4)} for k in (0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16)}},
 "radius": {"$type": "dimension", "sm": {"$value": px(4)}, "md": {"$value": px(8)}, "lg": {"$value": px(12)}, "pill": {"$value": px(999)}},
 "size": {"$type": "dimension",
   "touch-target": {"$value": px(44), "$description": "Alvo mínimo de toque (WCAG 2.5.8 pede 24; usamos 44)."},
   "seal-sm": {"$value": px(16)}, "seal-md": {"$value": px(20)}, "seal-lg": {"$value": px(24)},
   "icon": {"$value": px(20)}, "focus-ring": {"$value": px(2)}},
 "duration": {"$type": "duration", "fast": {"$value": {"value": 120, "unit": "ms"}}, "base": {"$value": {"value": 200, "unit": "ms"}}},
}
json.dump(tokens, open("out/tokens/rasto.tokens.json", "w"), ensure_ascii=False, indent=2)

# ---------- CSS ----------
def vars_for(mode, indent="  "):
    return "\n".join(f"{indent}--color-{k}: {v};" for k, v in PAL[mode].items())
css = ["/* Rasto (nome provisório) · variáveis CSS v1.0 · gerado de rasto.tokens.json */",
 "@import url('https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400..600&family=Lora:ital,wght@0,500..600;1,400&display=swap');",
 "", ":root {", "  color-scheme: light dark;", vars_for("light"),
 "  --seal-knock: #FFFFFF; /* cor do visto vazado dentro do selo cheio */",
 "  --seal-warn: var(--color-warning);",
 f"  --font-sans: {', '.join(repr(f) if ' ' in f else f for f in FONTS['sans'])};".replace("'", '"'),
 f"  --font-serif: {', '.join(repr(f) if ' ' in f else f for f in FONTS['serif'])};".replace("'", '"'),
 "  --weight-regular: 400; --weight-medium: 500; --weight-semibold: 600;"]
for n, fam, size, lh, w, tr in SCALE:
    css.append(f"  --text-{n}: {w} {size/16:g}rem/{round(lh/size,3)} var(--font-{fam}); --tracking-{n}: {tr}em;")
css += ["  " + " ".join(f"--space-{k}: {k*4/16:g}rem;" for k in (0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16)),
 "  --radius-sm: 4px; --radius-md: 8px; --radius-lg: 12px; --radius-pill: 999px;",
 "  --size-touch: 44px; --seal-sm: 16px; --seal-md: 20px; --seal-lg: 24px; --icon: 20px;",
 "  --duration-fast: 120ms; --duration-base: 200ms;",
 "  --shadow-1: 0 1px 2px rgb(27 26 34 / .06), 0 1px 3px rgb(27 26 34 / .08);",
 "}", "",
 "@media (prefers-color-scheme: dark) {", "  :root:not([data-theme=\"light\"]) {", vars_for("dark", "    "),
 "    --seal-knock: var(--color-on-primary);", "    --shadow-1: 0 1px 2px rgb(0 0 0 / .4);", "  }", "}",
 "[data-theme=\"dark\"] {", vars_for("dark"), "  --seal-knock: var(--color-on-primary);", "  --shadow-1: 0 1px 2px rgb(0 0 0 / .4);", "}", "",
 "/* Base */",
 "body { background: var(--color-bg); color: var(--color-text); font: var(--text-body); font-optical-sizing: auto; -webkit-font-smoothing: antialiased; }",
 ".num, .metric, td.num { font-variant-numeric: tabular-nums lining-nums; }",
 ":focus-visible { outline: var(--color-focus) solid 2px; outline-offset: 2px; }",
 "@media (prefers-reduced-motion: reduce) { * { transition-duration: 0ms !important; animation: none !important; } }",
]
open("out/tokens/rasto.css", "w").write("\n".join(css) + "\n")
print("tokens ok")
