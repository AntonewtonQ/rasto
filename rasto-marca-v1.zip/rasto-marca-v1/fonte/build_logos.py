"""Gera os SVG dos três conceitos de logótipo e dos selos de sinal."""
import os
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

OUT = "out/logo"; os.makedirs(OUT, exist_ok=True)
SIG = "out/sinais"; os.makedirs(SIG, exist_ok=True)
INK = "#3A2D8F"

FONT = TTFont("/usr/share/fonts/opentype/inter/InterDisplay-SemiBold.otf")
GS = FONT.getGlyphSet(); CMAP = FONT.getBestCmap(); UPM = FONT['head'].unitsPerEm

def text_path(txt, size, x0, baseline, tracking=-0.02):
    """Converte texto em path SVG (sem depender da fonte instalada)."""
    s = size/UPM; d = []; x = x0
    hmtx = FONT['hmtx']
    for ch in txt:
        g = CMAP[ord(ch)]
        pen = SVGPathPen(GS)
        GS[g].draw(TransformPen(pen, (s, 0, 0, -s, x, baseline)))
        d.append(pen.getCommands())
        x += hmtx[g][0]*s + tracking*size
    return " ".join(d), x

# ---------- símbolos (viewBox 24) ----------
SYMBOLS = {
 # A · Visto em rasto: três registos ligados que desenham um visto
 "a-visto-em-rasto": lambda c: f'''
  <path d="M4.5 12.5 L10 18 L19.5 6.5" fill="none" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="4.5" cy="12.5" r="2.6" fill="{c}"/>
  <circle cx="10" cy="18" r="2.6" fill="{c}"/>
  <circle cx="19.5" cy="6.5" r="3.6" fill="{c}"/>''',
 # B · Carimbo: o "r" dentro de um carimbo quadrado
 "b-carimbo": lambda c: f'''
  <mask id="rk"><rect width="24" height="24" fill="#fff"/>
   <path d="M9 18 V9.6 M9 12.4 C9.6 10.2 11.6 8.8 14.6 9" fill="none" stroke="#000" stroke-width="2.8" stroke-linecap="round"/>
   <circle cx="16.6" cy="9.1" r="1.9" fill="#000"/></mask>
  <rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="{c}" mask="url(#rk)"/>''',
 # C · Trilho: um "r" de linha contínua que termina no ponto presente
 "c-trilho": lambda c: f'''
  <path d="M6 21 V10 C6 6 9 3.8 13 3.8 C15.4 3.8 17 4.6 17.8 5.6" fill="none" stroke="{c}" stroke-width="2.8" stroke-linecap="round"/>
  <path d="M6 21 H3.5" stroke="{c}" stroke-width="2.8" stroke-linecap="round"/>
  <circle cx="19" cy="12.5" r="3.2" fill="{c}"/>''',
}

def svg(view, body, w=None, h=None, title="Rasto"):
    wh = f' width="{w}" height="{h}"' if w else ""
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{view}"{wh} role="img" aria-label="{title}"><title>{title}</title>{body}\n</svg>\n'

for key, fn in SYMBOLS.items():
    for variant, col in (("cor", INK), ("mono-preto", "#000000"), ("mono-branco", "#FFFFFF")):
        body = fn(col)
        open(f"{OUT}/{key}-simbolo-{variant}.svg", "w").write(svg("0 0 24 24", body, title=f"Rasto, símbolo {key}"))
    # assinatura horizontal: símbolo + palavra
    d, xend = text_path("rasto", 30, 40, 31)
    w = int(xend + 4)
    body = f'<g transform="translate(0,4) scale(1.5)">{fn(INK)}</g><path d="{d}" fill="#1B1A22"/>'
    open(f"{OUT}/{key}-assinatura-cor.svg", "w").write(svg(f"0 0 {w} 44", body, title="Rasto"))
    bodym = f'<g transform="translate(0,4) scale(1.5)">{fn("#000000")}</g><path d="{d}" fill="#000000"/>'
    open(f"{OUT}/{key}-assinatura-mono.svg", "w").write(svg(f"0 0 {w} 44", bodym, title="Rasto"))

# palavra sozinha
d, xend = text_path("rasto", 40, 0, 38)
open(f"{OUT}/palavra-rasto.svg", "w").write(svg(f"0 0 {int(xend)+2} 50", f'<path d="{d}" fill="#1B1A22"/>', title="Rasto"))

# favicon recomendado (A, com fundo para separar da barra do navegador)
fav = f'<rect width="24" height="24" rx="6" fill="{INK}"/>' + SYMBOLS["a-visto-em-rasto"]("#FFFFFF").replace('r="3.6"', 'r="3.4"')
open(f"{OUT}/favicon.svg", "w").write(svg("0 0 24 24", fav, title="Rasto"))

# ---------- selos de sinal (viewBox 24, currentColor) ----------
CHECK = '<path d="M7.6 12.3 L10.6 15.2 L16.4 9" fill="none" stroke="{k}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>'
def rosette(n=8, R=10.9, r=8.6, cx=12, cy=12):
    import math
    pts = []
    for i in range(n*2):
        a = math.pi*i/n - math.pi/2
        rad = R if i % 2 == 0 else r
        pts.append(f"{cx+rad*math.cos(a):.2f} {cy+rad*math.sin(a):.2f}")
    return "M" + " L".join(pts) + "Z"

SEALS = {
 # Nível alto: carimbo dentado cheio + visto vazado (MVP)
 "validado-alto": f'<path d="{rosette()}" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>' + CHECK.format(k="var(--seal-knock, #fff)"),
 # Nível intermédio [F]: círculo cheio + visto vazado
 "validado-intermedio": '<circle cx="12" cy="12" r="10" fill="currentColor"/>' + CHECK.format(k="var(--seal-knock, #fff)"),
 # Nível básico [F]: círculo em contorno + visto
 "validado-basico": '<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2"/>' + CHECK.format(k="currentColor"),
 # Declarado: círculo tracejado, sem visto, com traço horizontal ("dito, não confirmado")
 "declarado": '<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="3.2 2.6"/><path d="M8.5 12 H15.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
 # Pendente: forma do carimbo em tracejado + ponteiros de relógio
 "pendente": f'<path d="{rosette()}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-dasharray="2.4 2"/><path d="M12 7.6 V12 L15 13.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
 # Expirado: carimbo em contorno + barra diagonal
 "expirado": f'<path d="{rosette()}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M7.5 16.5 L16.5 7.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
 # Retirado: carimbo em contorno + X
 "retirado": f'<path d="{rosette()}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 9 L15 15 M15 9 L9 15" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
 # Validado com aviso: carimbo cheio + visto + triângulo no canto
 "validado-com-aviso": f'<path d="{rosette(R=10.2, r=8, cx=10.6, cy=11)}" fill="currentColor"/>' + '<path d="M7 12.3 L9.8 15 L15 9.4" fill="none" stroke="var(--seal-knock, #fff)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' + '<path d="M18.4 12 L23.6 22 H13.2 Z" fill="var(--seal-warn, #7A5000)" stroke="var(--seal-knock, #fff)" stroke-width="1.4" stroke-linejoin="round"/><path d="M18.4 15.6 V18.4" stroke="var(--seal-knock, #fff)" stroke-width="1.4" stroke-linecap="round"/>',
}
for k, body in SEALS.items():
    open(f"{SIG}/{k}.svg", "w").write(svg("0 0 24 24", body, title=k.replace('-', ' ')))
print("ok", len(os.listdir(OUT)), len(os.listdir(SIG)))
