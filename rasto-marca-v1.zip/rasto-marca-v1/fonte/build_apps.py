"""Aplicações de exemplo: ecrã de entrada, cartão de perfil, capa da defesa."""
import re
S = lambda n: re.sub(r"<title>.*?</title>", "", open(f"out/sinais/{n}.svg").read()).replace("<svg ", '<svg aria-hidden="true" ')
SYM = lambda c: f'''<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 12.5 L10 18 L19.5 6.5" fill="none" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="4.5" cy="12.5" r="2.6" fill="{c}"/><circle cx="10" cy="18" r="2.6" fill="{c}"/><circle cx="19.5" cy="6.5" r="3.6" fill="{c}"/></svg>'''
WORD = re.search(r'<path d="([^"]+)"', open("out/logo/palavra-rasto.svg").read()).group(1)
WVB = re.search(r'viewBox="([^"]+)"', open("out/logo/palavra-rasto.svg").read()).group(1)
def logo(c_sym="var(--color-primary)", c_word="var(--color-text)", h=28):
    return f'<span class="logo" style="height:{h}px">{SYM(c_sym)}<svg viewBox="{WVB}" aria-label="Rasto"><path d="{WORD}" fill="{c_word}"/></svg></span>'

# padrão inspirado nos sona (pontos + linha contínua). Não reproduz nenhum desenho tradicional.
def trilha(w, h, cols, rows, dot, line, sw=1.5, op=1):
    gx, gy = w/(cols+1), h/(rows+1)
    dots = "".join(f'<circle cx="{gx*(i+1):.1f}" cy="{gy*(j+1):.1f}" r="2.2" fill="{dot}"/>' for i in range(cols) for j in range(rows))
    pts = []
    for i in range(cols+1):
        x = gx*(i+0.5); y = gy*(0.5 if i % 2 == 0 else rows+0.5)
        pts.append((x, y))
    d = f"M{pts[0][0]:.1f} {pts[0][1]:.1f} " + " ".join(f"C{(a[0]+b[0])/2:.1f} {a[1]:.1f} {(a[0]+b[0])/2:.1f} {b[1]:.1f} {b[0]:.1f} {b[1]:.1f}" for a, b in zip(pts, pts[1:]))
    return f'<svg viewBox="0 0 {w} {h}" preserveAspectRatio="xMidYMid slice" aria-hidden="true" style="opacity:{op}">{dots}<path d="{d}" fill="none" stroke="{line}" stroke-width="{sw}" stroke-linecap="round"/></svg>'

def entrada(theme):
    return f'''
<div class="phone" data-theme="{theme}"><div class="screen">
  <div class="hero">{trilha(360, 150, 6, 3, "var(--color-primary)", "var(--color-secondary)", 2, .55)}</div>
  <div class="pad">
    {logo()}
    <h1 class="display">Confiança que se verifica.</h1>
    <p class="muted">Startups e investidores em Angola, com sinais confirmados por aceleradoras e universidades.</p>
    <label class="field"><span>E-mail</span><input value="nadia@kifuta.ao" readonly></label>
    <label class="field"><span>Palavra-passe</span><input type="password" value="••••••••••" readonly></label>
    <button class="btn">Entrar</button>
    <a class="link center">Esqueceu a palavra-passe?</a>
    <hr>
    <p class="small">Investidor? <a class="link">Criar conta</a></p>
    <p class="small">Aceleradora ou universidade? <a class="link">Pedir registo</a></p>
    <p class="small subtle">As startups entram por convite da sua aceleradora.<br><a class="link">Como tratamos os seus dados (Lei n.º 22/11)</a></p>
  </div>
</div><div class="cap">Ecrã de entrada · modo {"claro" if theme=="light" else "escuro"}</div></div>'''

def sinal(kind, titulo, linha2, est):
    return f'''<li class="sig sig-{kind}"><span class="seal">{S(kind)}</span><div><div class="sig-state">{est}</div><div class="sig-title">{titulo}</div><div class="sig-meta">{linha2}</div></div></li>'''

def cartao(theme):
    return f'''
<div class="phone" data-theme="{theme}"><div class="screen">
  <div class="topbar"><span class="back">‹ Sugestões</span></div>
  <div class="pad">
    <div class="head"><div class="avatar">KA</div><div><h2>Kifuta Agro</h2><div class="muted small">Agritech · Pré-seed · Luanda</div></div></div>
    <p class="body-sm">Logística de frescos entre produtores do Bengo e cantinas de Luanda.</p>
    <div class="ronda"><div><div class="caption">Ronda</div><div class="metric num">USD 80 000</div></div>
      <div><div class="caption">Compromisso</div><div class="metric num">35%</div></div></div>
    <div class="bar"><span style="width:35%"></span></div>

    <h3 class="sec">Verificado</h3>
    <ul class="sigs">
      {sinal("validado-alto", "Participou no Programa de Aceleração 2025 (Mar.–Jun.)", "Validado por <b>Aceleradora X</b> · 12/07/2025<br>Entidade verificada pela plataforma", "Validado · nível alto")}
      {sinal("validado-alto", "MVP lançado (Mar. 2025)", "Validado por <b>Aceleradora X</b> · 20/07/2025", "Validado · nível alto")}
    </ul>
    <h3 class="sec">Declarado pela startup</h3>
    <ul class="sigs">
      {sinal("declarado", "Primeiro cliente pagante (Nov. 2025)", "Ainda sem validação", "Declarado")}
    </ul>

    <div class="match"><div class="match-h"><span>Compatibilidade com o seu mandato</span><b class="num">87/100</b></div>
      <div class="row num"><span>Sector</span><span>40/40</span></div>
      <div class="row num"><span>Fase</span><span>25/25</span></div>
      <div class="row num"><span>Valor do cheque · parcial</span><span>12/25</span></div>
      <div class="row num"><span>Geografia</span><span>10/10</span></div>
      <p class="caption subtle">Mede o encaixe com o seu mandato, não a qualidade da startup.</p></div>
    <p class="caption subtle">Actualizado há 6 dias</p>
    <button class="btn">Pedir acesso</button>
  </div>
</div><div class="cap">Perfil da startup, camada 1 (vista do investidor) · dados fictícios</div></div>'''

def capa():
    return f'''
<div class="slide"><div class="slide-art">{trilha(1280, 720, 9, 4, "rgba(255,255,255,.35)", "#F09A70", 2.2, 1)}</div>
  <div class="slide-in">
    <div class="slide-top">{logo("#FFFFFF", "#FFFFFF", 34)}<span>Instituto Superior Politécnico de Tecnologias e Ciências · ISPTEC</span></div>
    <div>
      <div class="kicker">Trabalho de Conclusão de Curso</div>
      <h1 class="slide-title">Rasto: gestão e ligação entre startups aceleradas e investidores em Angola</h1>
      <p class="slide-sub">Sinais verificáveis e acompanhamento depois da ligação</p>
    </div>
    <div class="slide-foot"><span>{{Nome completo do autor}}</span><span>Orientador: {{nome}}</span><span>Luanda, {{data da defesa}}</span></div>
  </div></div><div class="cap">Capa da apresentação de defesa (16:9)</div>'''

css = open("out/tokens/rasto.css").read().split("\n", 2)[2]  # sem @import: fontes locais no ensaio
html = f'''<!doctype html><html lang="pt-AO"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rasto · aplicações</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400..600&family=Lora:ital,wght@0,500..600;1,400&display=swap" rel="stylesheet">
<style>{css}
body{{margin:0;padding:32px;background:#E9E6DF}}
.grid{{display:flex;gap:32px;flex-wrap:wrap;align-items:flex-start}}
.phone{{width:360px;background:var(--color-bg);color:var(--color-text);border-radius:28px;overflow:hidden;box-shadow:0 10px 30px rgb(0 0 0/.15);font:var(--text-body);font-family:var(--font-sans)}}
.phone .cap,.cap{{background:#E9E6DF;color:#55515F;font:500 12px Inter;padding:10px 4px}}
.screen{{min-height:740px}}
.hero{{height:120px;background:var(--color-primary-subtle);overflow:hidden}} .hero svg{{width:100%;height:100%}}
.pad{{padding:20px}}
.logo{{display:inline-flex;align-items:center;gap:6px}} .logo svg{{height:100%;width:auto}}
.display{{font:var(--text-display);letter-spacing:var(--tracking-display);margin:20px 0 8px;font-size:2.125rem;line-height:1.1}}
h2{{font:var(--text-h2);margin:0}} .muted{{color:var(--color-text-muted)}} .subtle{{color:var(--color-text-subtle)}}
.small,.body-sm{{font:var(--text-body-sm)}} .caption{{font:var(--text-caption);color:var(--color-text-muted)}}
.field{{display:block;margin-top:16px}} .field span{{font:var(--text-label);display:block;margin-bottom:6px}}
.field input{{box-sizing:border-box;width:100%;height:var(--size-touch);border:1px solid var(--color-border-strong);border-radius:var(--radius-md);background:var(--color-surface);color:var(--color-text);padding:0 12px;font:var(--text-body)}}
.btn{{width:100%;height:48px;margin-top:20px;border:0;border-radius:var(--radius-md);background:var(--color-primary);color:var(--color-on-primary);font:600 16px var(--font-sans)}}
.link{{color:var(--color-primary);text-decoration:underline;text-underline-offset:3px;font-weight:500}} .center{{display:block;text-align:center;margin-top:14px;font:var(--text-body-sm);font-weight:500}}
hr{{border:0;border-top:1px solid var(--color-border);margin:20px 0}}
.topbar{{padding:16px 20px 0;color:var(--color-primary);font:var(--text-label)}}
.head{{display:flex;gap:12px;align-items:center}} .avatar{{width:48px;height:48px;border-radius:12px;background:var(--color-secondary-subtle);color:var(--color-secondary);display:grid;place-items:center;font:600 18px var(--font-sans)}}
.ronda{{display:flex;gap:32px;margin-top:16px}} .metric{{font:var(--text-metric);letter-spacing:var(--tracking-metric)}}
.bar{{height:8px;border-radius:99px;background:var(--color-surface-sunken);margin-top:10px;overflow:hidden;border:1px solid var(--color-border)}} .bar span{{display:block;height:100%;background:var(--color-secondary)}}
.sec{{font:var(--text-caption);text-transform:uppercase;letter-spacing:.06em;color:var(--color-text-muted);margin:22px 0 8px}}
.sigs{{list-style:none;margin:0;padding:0;display:grid;gap:8px}}
.sig{{display:flex;gap:12px;padding:12px;border-radius:var(--radius-lg);align-items:flex-start}}
.sig-validado-alto{{background:var(--color-surface);border:1px solid var(--color-primary);box-shadow:inset 3px 0 0 var(--color-primary)}}
.sig-declarado{{background:transparent;border:1px dashed var(--color-border-strong)}}
.seal{{width:24px;height:24px;flex:none;color:var(--color-primary)}} .sig-declarado .seal{{color:var(--color-text-muted)}} .seal svg{{width:100%;height:100%;display:block}}
.sig-state{{font:var(--text-caption);text-transform:uppercase;letter-spacing:.05em;color:var(--color-primary)}} .sig-declarado .sig-state{{color:var(--color-text-muted)}}
.sig-title{{font:600 15px/1.35 var(--font-sans);margin-top:2px}} .sig-meta{{font:var(--text-body-sm);color:var(--color-text-muted);margin-top:4px}} .sig-meta b{{color:var(--color-text);font-weight:600}}
.match{{margin-top:20px;padding:14px;border-radius:var(--radius-lg);background:var(--color-surface-sunken)}}
.match-h{{display:flex;justify-content:space-between;font:var(--text-label);margin-bottom:8px}} .row{{display:flex;justify-content:space-between;font:var(--text-body-sm);padding:3px 0}}
.slide{{width:1280px;height:720px;position:relative;background:#2A2068;color:#fff;overflow:hidden;font-family:var(--font-sans)}}
.slide-art{{position:absolute;inset:0}} .slide-art svg{{width:100%;height:100%}}
.slide-in{{position:absolute;inset:0;padding:72px 88px;display:flex;flex-direction:column;justify-content:space-between;background:linear-gradient(90deg,#2A2068 45%,rgb(42 32 104/.55))}}
.slide-top{{display:flex;align-items:center;justify-content:space-between;font:500 16px var(--font-sans);opacity:.9}}
.kicker{{font:600 15px var(--font-sans);letter-spacing:.12em;text-transform:uppercase;color:#F6C2A6}}
.slide-title{{font:600 58px/1.08 var(--font-serif);max-width:860px;margin:16px 0}} .slide-sub{{font:400 22px var(--font-sans);opacity:.85;margin:0}}
.slide-foot{{display:flex;gap:48px;font:500 17px var(--font-sans);opacity:.9;border-top:1px solid rgb(255 255 255/.25);padding-top:20px}}
</style></head><body>
<div class="grid">{entrada("light")}{entrada("dark")}{cartao("light")}{cartao("dark")}</div>
<div style="margin-top:40px">{capa()}</div>
</body></html>'''
open("out/aplicacoes.html", "w").write(html)
print("ok")
